//make a hidden div and utilize map for classy services price (length, price) and have hidden until a length is chosen
const frenchTipMap = new Map([
["small", 50],
["medium", 55],
["large", 65],
["extra-large", 75],
])

const ombreMap = new Map([
["small", 50],
["medium", 55],
["large", 65],
["extra-large", 75]
])

const fullMarbleMap = new Map([
["small", 50],
["medium", 55],
["large", 65],
["extra-large", 75]
])

for (const x of frenchTipMap.values()){
    console.log(x)

}