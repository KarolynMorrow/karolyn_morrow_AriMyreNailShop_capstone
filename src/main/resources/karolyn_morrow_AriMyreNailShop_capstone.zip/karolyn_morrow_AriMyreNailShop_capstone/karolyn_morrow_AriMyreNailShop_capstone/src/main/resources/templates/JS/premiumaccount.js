let firstName = document.getElementById("firstName");
let lastName = document.getElementById("lastName");
let greeting = console.log("Welcome " + firstName + " " + lastName);