package com.perscholas.AriMyreNailShop;

public interface INailShop {
    final boolean isAdmin = false;

    /*METHODS*/
    public boolean isPremium();
}
