package com.perscholas.AriMyreNailShop.controllers;

import com.perscholas.AriMyreNailShop.models.Account;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AccountController {
    @PostMapping
    public void createAccount(Account account){
        // I need to reconstruct client name
    }





}
