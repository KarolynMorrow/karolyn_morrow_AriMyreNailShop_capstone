package com.perscholas.AriMyreNailShop.controllers;


import org.springframework.stereotype.Controller;

@Controller
public class PremiumAccountController {


}
